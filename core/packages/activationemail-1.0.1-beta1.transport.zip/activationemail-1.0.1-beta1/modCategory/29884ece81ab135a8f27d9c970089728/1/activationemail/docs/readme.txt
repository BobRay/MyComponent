Modx ActivationEmail Package
====================
Author: Bob Ray <http://bobsguides.com>
Date:   02/01/2011
====================

This plugin sends an email message to users manually activated in the
Manager and (optionally) to deactivated users.

Tutorial: http://bobsguides.com/activationemail-plugin-tutorial.html
Bugs and Suggestions: https://github.com/BobRay/ActivationEmail/issues
Questions about using the plugin: http://modxcms.com/forums